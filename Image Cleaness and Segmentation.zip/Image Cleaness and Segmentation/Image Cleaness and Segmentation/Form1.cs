﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using AForge.Imaging;
using AForge.Imaging.Filters;

namespace Image_Cleaness_and_Segmentation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            string path = "";

            if (fbd.ShowDialog() == DialogResult.OK)
            {
                path = fbd.SelectedPath;
                string[] Files = Directory.GetFiles(path, "*.jpg");
                if (!Directory.Exists("Cleaned Images")) Directory.CreateDirectory("Cleaned Images");
                string cleanedPath = "Cleaned Images";
                int t = 1;
                foreach (var file in Files)
                {
                    Bitmap captcha = (Bitmap)Bitmap.FromFile(file);
                    Bitmap clean;
                    pictureBox1.Image = captcha;
                    string captchaName = Path.GetFileName(file);
                    char[] name = captchaName.ToCharArray();
                    Grayscale filter = new Grayscale(0.2125, 0.7154, 0.0721);
                    filter.Apply(captcha);
                    clean = DilationFilter(captcha);
                    clean = DilationFilter(clean);
                    clean = ErosionFilter(clean);
                    //clean = ErosionFilter(clean);
                    clean.Save(cleanedPath + @"\"+ captchaName);
                    Bitmap[] cropped = SegmentImage(clean);
                    pictureBox2.Image = cropped[0];
                    pictureBox3.Image = cropped[1];
                    pictureBox4.Image = cropped[2];
                    pictureBox5.Image = cropped[3];
                    pictureBox6.Image = cropped[4];
                    pictureBox7.Image = cropped[5];
                    int i = 0;
                    string imagName = new string(name,0 ,6);
                    char[] Onlyname = imagName.ToCharArray();

                    foreach (char ch in Onlyname)
                    {
                        if (!Directory.Exists(@"Segmented Images\" + ch.ToString().ToUpper()))
                            Directory.CreateDirectory(@"Segmented Images\" + ch.ToString().ToUpper());
                        cropped[i].Save(@"Segmented Images\" + ch.ToString().ToUpper() + @"\" + t + ".jpg");
                        i++;
                        t++;
                    }
                    cropped = null;
                }
            }
        }

        private Bitmap[] SegmentImage(Bitmap captcha)
        {
            int x = 12;
            int width = 28;
            Bitmap[] segments = new Bitmap[6];

            for (int i = 0; i < 6; i++)
            {
                Crop cropFilter = new Crop(new Rectangle(x, 10, width, 40));
                x += width;
                segments[i] = cropFilter.Apply(captcha);

            }
            return segments;
        }

        private Bitmap DilationFilter(Bitmap captcha)
        {
            Dilatation DLfilter = new Dilatation();
            return DLfilter.Apply(captcha);
        }

        private Bitmap ErosionFilter(Bitmap captcha)
        {
            Erosion ERfilter = new Erosion();
            return ERfilter.Apply(captcha);
        }
    }
}
